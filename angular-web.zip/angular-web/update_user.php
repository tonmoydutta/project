<?php

$connection=mysqli_connect('localhost','root','','angular');
$update_data=json_decode(file_get_contents("php://input"));

$update_slno=$update_data->update_slno;

$update_name=$update_data->update_name;

$update_email=$update_data->update_email;

$update_mob=$update_data->update_mob;

if(empty($update_name)){

	$response['message']='Please enter your name.';
	$response['status1']=0;
}

else if(empty($update_email)){

	$response['message']='Please enter your email.';
	$response['status1']=0;
}

else if(!filter_var($update_email, FILTER_VALIDATE_EMAIL))
{ 
    $response['message']='Please enter valid email.';
	$response['status1']=0;
}

else if(empty($update_mob)){

	$response['message']='Please enter your mobile.';
	$response['status1']=0;
}

else{
$update_sql=mysqli_query($connection,"update tbl_user set name='".$update_name."',email='".$update_email."',mobile='".$update_mob."' where slno='".$update_slno."'");

if($update_sql){

	    $response['message']='User updated successfully.';
	    $response['status1']=1;
  }
}
echo json_encode($response);

?>