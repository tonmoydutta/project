<?php

$connection=mysqli_connect('localhost','root','','angular');

$query=mysqli_query($connection,"select * from tbl_user ");

while($row=mysqli_fetch_array($query)){

 
	$data[]=$row;

}


//echo $data;
echo json_encode($data);



?>