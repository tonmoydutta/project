<?php

$connection=mysqli_connect('localhost','root','','angular');
$delete_data=json_decode(file_get_contents("php://input"));

$slno=$delete_data->user_slno;

// echo "delete from angular where slno='".$slno."'";
// exit;
$delete_sql=mysqli_query($connection,"delete from tbl_user where slno='".$slno."'");

if($delete_sql){

	$response['message']='User deleted successfully.';
	$response['status']=1;
}

echo json_encode($response);

?>