
var app = angular.module('MyApp', ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {

        templateUrl : "home.html",
        controller: "homecontroller",
        activetab: 'home'
    })
    .when("/about", {
        templateUrl : "about.html",
        controller: "aboutcontroller",
        activetab: 'about'
    })
    .when("/contact", {
        templateUrl : "contact.html",
        controller: "contactecontroller",
        activetab: 'contact'
    })
    .when("/user", {
        templateUrl : "user.html",
        controller: "usercontroller",
        activetab: 'user'
    })
    .when("/login", {
        templateUrl : "login.html",
        controller: "logincontroller",
        activetab: 'login'
    })
    .otherwise({ redirectTo: '/' });
});

app.controller('homecontroller',function($scope,$http){

    $scope.displayHome=function(){
    
       $http({

              method:'GET',
              url:'display_home.php'
          }).then(function myfunction(ff){

             console.log(ff);
            $scope.frontpage = ff.data;
         

       }) ;
    }



});

app.controller('aboutcontroller',function($scope,$http){

    $scope.displayData=function(){

    $http({

            method: 'GET',
            url: 'display.php'
            }).then(function successCallback(response) {
            console.log(response.data);
            $scope.users = response.data;
 });

       }

});



app.controller('contactecontroller',function($scope,$http){

$scope.insert={};

$scope.insert_data=function(){

    $http({

           method:'POST',
           url:'insert.php',
           data:{
                   name    :$scope.insert.your_name,
                   emailid :$scope.insert.your_email,
                   mobile  :$scope.insert.your_mobile

           }
    
    }).then(function form(fhfhf){

      console.log(fhfhf);

      $scope.success=fhfhf.data;
      
    });
}





 });


app.controller('usercontroller',function($scope,$http,$window){

  $scope.saveuser=function(){

    $http({

           method:'POST',
           url:'add_user.php',
           data:{
                   
                   name :$scope.value.name,
                   uemail  :$scope.value.email,
                   umob  :$scope.value.mobile,
                   headers : {'Content-Type': 'application/x-www-form-urlencoded'}

           }

          // console.log(data);
    
    }).then(function add(sssss){

      //console.log(sssss);
      $scope.users.push($scope.value);
      $scope.error_success=sssss.data.message;
      $scope.value={};

    });


  }


  $scope.alluser=function(){



    $http({

            method: 'GET',
            url :   'get_user.php'
          }).then(function all_user(as){

             console.log(as);
             $scope.users=as.data;
          });


  }


$scope.selectuser=function(user){
    $scope.clicked=user;
}

$scope.update=function(){

  

  $http({

          method:'POST',
          url:'update_user.php',
          data:{

               update_slno:$scope.clicked.slno,
               update_name:$scope.clicked.name,
               update_email:$scope.clicked.email,
               update_mob:$scope.clicked.mobile
          }

       }).then(function updateuser(update_user){

        console.log(update_user);

         $scope.show_update_message=update_user.data.message;

       });
  
}


$scope.deleteuser=function(slno){

  if ($window.confirm("Please confirm?")) {
      //$scope.Message = "You clicked YES.";

      $http({

          method : 'POST',
          url    :'delete_user.php',
          data   :{

                    user_slno:slno
                   }     

      }).then(function delete_user(del){


       console.log(del);
       $scope.delete_message=del.data.message;
       $scope.users.splice($scope.users.indexOf($scope.clicked),1);

      }); 
  } 



}


});