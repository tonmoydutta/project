<?php

$connection=mysqli_connect('localhost','root','','angular');

$add_data=json_decode(file_get_contents("php://input"));



$show_message=array();

if(empty($add_data->name)){

	$show_message['message']='Please enter your name.';
    $show_message['status']=0;
}

// else if(empty($add_data->lname)){
// 	$show_message['message']='Please enter your last name.';
//     $show_message['status']=0;
// }

else if(empty($add_data->uemail)){
	$show_message['message']='Please enter your email.';
    $show_message['status']=0;
}

else if(empty($add_data->umob)){
	$show_message['message']='Please enter your mobile.';
    $show_message['status']=0;
}

else{

	$fullname=mysqli_real_escape_string($connection,$add_data->name);

	$user_email=mysqli_real_escape_string($connection,$add_data->uemail);

	$user_mobile=mysqli_real_escape_string($connection,$add_data->umob);

  
	$insert_user=mysqli_query($connection,"insert into tbl_user(name,email,mobile) values ('".$fullname."','".$user_email."','".$user_mobile."')");

	if($insert_user){

	$show_message['message']='User Added Successfully.';
    $show_message['status']=1;

}
}

echo json_encode($show_message);

?>