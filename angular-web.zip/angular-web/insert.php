<?php

$connection=mysqli_connect('localhost','root','','angular');
$form_data=json_decode(file_get_contents("php://input"));
 
$response=array();


if(empty($form_data->name)){

	$response['message']='Name is required.';
	$response['status1']=0;
}
else if(empty($form_data->emailid)){

	$response['message']='Email is required.';
	$response['status1']=0;
}

else if(!filter_var($form_data->emailid, FILTER_VALIDATE_EMAIL))
{ 
    $response['message']='Invalid email.';
	$response['status1']=0;
}

else if(empty($form_data->mobile)){

	$response['message']='Mobile is required.';
	$response['status1']=0;
}

else{

	$fullname=mysqli_real_escape_string($connection,$form_data->name);

	$email=mysqli_real_escape_string($connection,$form_data->emailid);

	$mobile=mysqli_real_escape_string($connection,$form_data->mobile);

	

	$insert=mysqli_query($connection,"insert into tbl_user (name,email,mobile) values ('".$fullname."','".$email."','".$mobile."')");

	if($insert){

		$response['message']='Data submitted successfully.';
	    $response['status1']=1;
	}

	
}

echo json_encode($response);
?>
