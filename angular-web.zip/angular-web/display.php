<?php

$connection=mysqli_connect('localhost','root','','angular');

 
$data=array();

$sql=mysqli_fetch_array(mysqli_query($connection,"select * from tbl_about"));


$data['title']=$sql['title'];

$data['description']=$sql['description'];


echo json_encode($data);
?>
