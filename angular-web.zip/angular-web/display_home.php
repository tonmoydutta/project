<?php

$connection=mysqli_connect('localhost','root','','angular');

 
$homecontent=array();

$sql=mysqli_fetch_array(mysqli_query($connection,"select * from tbl_home"));


$homecontent['title']=$sql['title'];

$homecontent['description']=$sql['description'];

$homecontent['image']=$sql['image'];


echo json_encode($homecontent);
?>
